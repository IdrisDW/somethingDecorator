﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaDecorador
{
    public abstract class Beverage
    {
        private BeverageSize size;



        public virtual string GetDescription()

        {

            return "Unknown Beverage";

        }



        public BeverageSize Size

        {

            get

            {

                return size;

            }

            set

            {

                size = value;

            }

        }



        public abstract double Cost();

 

}
}
