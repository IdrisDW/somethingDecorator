﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaDecorador
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ticket();
        }

        string user = "algo";
        SqlConnection conn = new SqlConnection(Conexion.SConexion());


        void ticket() {







            Document pdfDoc = new Document(PageSize.A4, 70f, 70f, 10f, 0f);
            PdfWriter wri = PdfWriter.GetInstance(pdfDoc, new FileStream(@"C:\Users\Juliet\source\repos\PracticaDecorador\Resources\NOTA.pdf", FileMode.Create));
            float percentage = 0.0f;

            pdfDoc.Open();

            iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(@"C:\Users\Juliet\source\repos\PracticaDecorador\Resources\Image1.jpg");

            Paragraph parrafo2 = new Paragraph(string.Format("\n\n\n\n\nNota de Venta Celular\n\nDatos Generales de Venta"), new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12));
            parrafo2.SpacingBefore = 200;
            parrafo2.SpacingAfter = 0;
            parrafo2.Alignment = 1; //0-Left, 1 middle,2 Right

            //Paragraph parrafo4 = new Paragraph(string.Format("\n\nTijuana B.C.               \nFecha:               "));
            //parrafo4.Alignment = 2;

            Paragraph parrafo3 = new Paragraph(string.Format("\n\n\n" + "LISTA DE CELULARES"));
            parrafo3.SpacingAfter = 0;
            parrafo3.Alignment = 0;

            //LISTA DE CELULARES COMPRADOS

            #region LISTA_COMPRA


            //Buscar lista de compra
            string sqlselect = "SELECT * FROM Compra WHERE Usuario='" + user + "'";
            SqlCommand queryS = new SqlCommand(sqlselect, conn);
            DataSet dsCompras = new DataSet();
            SqlDataAdapter adaptador = new SqlDataAdapter(queryS);


            try
            {
                conn.Open();

                adaptador.SelectCommand = queryS;
                adaptador.Fill(dsCompras, "Compra");

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
         //   dgvCarrito.DataSource = dsCompras.Tables["Compra"];

            pdfDoc.Add(parrafo2);
            //pdfDoc.Add(parrafo4);
            pdfDoc.Add(parrafo3);
            //pdfDoc.Add(parrafo5);

            Paragraph parrafo5 = new Paragraph(string.Format("\n\n"));
            parrafo5.Alignment = 1;
          
            #endregion


            Paragraph parrafo6 = new Paragraph(string.Format("\n\n\nCosto Total : $ " ) );
            parrafo6.Alignment = 2;

            DateTime fecha = DateTime.Now;
            Paragraph parrafo7 = new Paragraph(string.Format("\n" + fecha.ToString()));
            parrafo7.Alignment = 1;


            pdfDoc.Add(parrafo6);
            pdfDoc.Add(parrafo7);
            pdfDoc.Add(Chunk.NEWLINE);

       
            img.SetAbsolutePosition(490, 740);
            percentage = 95 / img.Width;
            img.ScalePercent(percentage * 100);
            pdfDoc.Add(img);
            img.ScaleToFit(115f, 50F);

            pdfDoc.Close();









        }
    }
}
